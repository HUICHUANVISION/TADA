import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.io import arff
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import f1_score, accuracy_score, roc_auc_score, confusion_matrix, precision_score, recall_score, matthews_corrcoef
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE, ADASYN, RandomOverSampler, BorderlineSMOTE
from imblearn.combine import SMOTEENN
from imblearn.over_sampling import KMeansSMOTE, SVMSMOTE
from imblearn.under_sampling import RandomUnderSampler
from imblearn.combine import SMOTETomek
# ---------------- 采样方法 ----------------
def mpos_sampling(X, y):
    X_minority = X[y == 1]
    n_min = len(X_minority)
    n_major = len(y) - n_min
    n_to_generate = n_major - n_min
    if n_to_generate <= 0:
        return X, y

    X_generated = []
    for _ in range(n_to_generate):
        x = X_minority[np.random.randint(n_min)]
        # 找最近邻（简单实现：随机选另一个样本）
        x_near = X_minority[np.random.randint(n_min)]
        r = np.random.rand()
        x_new = x + r * (x - x_near)
        X_generated.append(x_new)

    X_aug = np.vstack([X, np.array(X_generated)])
    y_aug = np.hstack([y, np.ones(len(X_generated))])
    return X_aug, y_aug
AUGMENTATION_METHODS = {
    'smote': lambda X, y: SMOTE(random_state=42).fit_resample(X, y),
    'adasyn': lambda X, y: ADASYN(random_state=42).fit_resample(X, y),
    'ros': lambda X, y: RandomOverSampler(random_state=42).fit_resample(X, y),
    'borderline': lambda X, y: BorderlineSMOTE(random_state=42).fit_resample(X, y),
    'smoteenn': lambda X, y: SMOTEENN(random_state=42).fit_resample(X, y),
    'mpos': mpos_sampling  # ✅ 新增 MPOS

    # # 新增方法
    # 'kmeanssmote': lambda X, y: KMeansSMOTE(random_state=42).fit_resample(X, y),
    # 'svmsmote': lambda X, y: SVMSMOTE(random_state=42).fit_resample(X, y),
    # 'smotetomek': lambda X, y: SMOTETomek(random_state=42).fit_resample(X, y),
    # 'undersample': lambda X, y: RandomUnderSampler(random_state=42).fit_resample(X, y),
}

# ---------------- 评估模块 ----------------
def clean_and_binarize_label(x):
    if isinstance(x, bytes): x = x.decode('utf-8')
    x = str(x).strip().lower()
    if x in ['1', 'bug', 'buggy', 'yes', 'true']: return 1
    elif x in ['0', 'nonbug', 'clean', 'no', 'false']: return 0
    try: return 1 if float(x) > 0 else 0
    except: return 0

def calculate_metrics(y_true, y_pred, y_score):
    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    auc = roc_auc_score(y_true, y_score) if len(np.unique(y_true)) == 2 else 0.5
    cm = confusion_matrix(y_true, y_pred)
    if cm.shape == (2,2):
        tn, fp, fn, tp = cm.ravel()
        bacc = 0.5 * (tp / (tp + fn + 1e-6) + tn / (tn + fp + 1e-6))
        pf = fp / (fp + tn + 1e-6)
    else:
        bacc, pf = 0.0, 1.0
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    g_measure = 2 * (precision * recall) / (precision + recall + 1e-6)
    mcc = matthews_corrcoef(y_true, y_pred)
    return {
        "ACC": acc, "F1": f1, "BACC": bacc, "G": g_measure,
        "AUC": auc, "MCC": mcc, "Pf": pf
    }

# ---------------- MMD计算 ----------------
def compute_mmd(X1, X2):
    return np.linalg.norm(np.mean(X1, axis=0) - np.mean(X2, axis=0))
def compute_composite_score(metrics, weights=None):
    """
    metrics: dict, contains scores from `calculate_metrics`
    weights: dict or None, weight for each metric
    """

    def compute_composite_score(metrics, weights=None):
        # 只保留 F1、MCC、Pf
        default_weights = {
            "ACC": 0.0,
            "F1": 2.0,
            "BACC": 0.0,
            "G": 0.0,
            "AUC": 0.0,
            "MCC": 2.0,
            "Pf": -1.5  # Pf 越小越好，保持负权重
        }
        if weights is None:
            weights = default_weights

        score = 0.0
        for key, weight in weights.items():
            score += weight * metrics[key]
        return score
# ---------------- 遗传增强主逻辑 ----------------
def evaluate_strategy(strategy, X, y, X_t_sample):
    X_current, y_current = X.copy(), y.copy()
    try:
        for method in strategy:
            X_current, y_current = AUGMENTATION_METHODS[method](X_current, y_current)

        model = LogisticRegression(max_iter=1000)
        metrics_list = []
        skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
        for train_idx, val_idx in skf.split(X_current, y_current):
            model.fit(X_current[train_idx], y_current[train_idx])
            preds = model.predict(X_current[val_idx])
            probs = model.predict_proba(X_current[val_idx])[:, 1]
            metrics = calculate_metrics(y_current[val_idx], preds, probs)
            metrics_list.append(metrics)

        # 取平均指标
        avg_metrics = {key: np.mean([m[key] for m in metrics_list]) for key in metrics_list[0]}

        # 计算 MMD 作为额外项（如有必要）
        mmd_score = -compute_mmd(X_current, X_t_sample)

        # 综合打分
        score = compute_composite_score(avg_metrics) + 0.5 * mmd_score  # 可调α

        return score
    except:
        return -np.inf

def genetic_sampling_selection(X_s, y_s, X_t_sample, pop_size=10, generations=5, alpha=0.5):
    method_names = list(AUGMENTATION_METHODS.keys())
    # 初始化种群
    population = [random.choices(method_names, k=random.randint(1, 3)) for _ in range(pop_size)]

    for _ in range(generations):
        scores = [evaluate_strategy(ind, X_s, y_s, X_t_sample) for ind in population]
        sorted_indices = np.argsort(scores)[::-1]
        population = [population[i] for i in sorted_indices]
        scores = [scores[i] for i in sorted_indices]  # 同步排序

        parents = population[:pop_size // 2]
        parent_scores = scores[:pop_size // 2]

        children = []
        while len(children) < pop_size // 2:
            # 分布对齐感知：平移并归一化父代分数为概率分布
            min_score = min(parent_scores)
            shifted_scores = [s - min_score + 1e-6 for s in parent_scores]
            total_score = sum(shifted_scores) + 1e-6
            prob_dist = [s / total_score for s in shifted_scores]

            # 精确归一化，确保概率和等于1
            prob_sum = sum(prob_dist)
            prob_dist = [p / prob_sum for p in prob_dist]

            p1_idx, p2_idx = np.random.choice(len(parents), size=2, replace=False, p=prob_dist)
            p1, p2 = parents[p1_idx], parents[p2_idx]

            min_len = min(len(p1), len(p2))
            if min_len <= 1:
                child = p1.copy()
            else:
                cut = random.randint(1, min_len - 1)
                child = p1[:cut] + p2[cut:]

            if random.random() < 0.3:
                mutation = random.choice(method_names)
                if mutation not in child:
                    child.append(mutation)

            children.append(child)

        population = parents + children

    best_strategy = population[0]
    X_final, y_final = X_s, y_s
    for method in best_strategy:
        X_final, y_final = AUGMENTATION_METHODS[method](X_final, y_final)
    return X_final, y_final, "+".join(best_strategy)

def intelligent_augmentation_ga(X, y, Xt_sample, pop_size=60, generations=30, alpha=0.5):
    pos_idx = np.where(y == 1)[0]
    neg_idx = np.where(y == 0)[0]
    if len(pos_idx) == 0 or len(neg_idx) == 0:
        return X, y, 'none'
    return genetic_sampling_selection(X, y, Xt_sample, pop_size, generations, alpha)

# ---------------- ResNet结构 ----------------
def relu_bn_fc(in_dim, out_dim):
    return nn.Sequential(nn.Linear(in_dim, out_dim), nn.BatchNorm1d(out_dim), nn.ReLU())

class BasicBlock(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.bn1 = nn.BatchNorm1d(hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, input_dim)
        self.bn2 = nn.BatchNorm1d(input_dim)
    def forward(self, x):
        identity = x
        out = F.relu(self.bn1(self.fc1(x)))
        out = self.bn2(self.fc2(out))
        out += identity
        return F.relu(out)

class FeatureMapperResNet(nn.Module):
    def __init__(self, input_dim, mapped_dim=128, num_blocks=3):
        super().__init__()
        self.input_layer = nn.Linear(input_dim, 256)
        self.res_blocks = nn.Sequential(*[BasicBlock(256, 512) for _ in range(num_blocks)])
        self.output_layer = nn.Linear(256, mapped_dim)
    def forward(self, x):
        x = F.relu(self.input_layer(x))
        x = self.res_blocks(x)
        x = self.output_layer(x)
        return x

class Classifier(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, num_classes=2):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, num_classes)
    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))

# ---------------- 数据加载 ----------------
def load_multi_source_data(source_folders, target_file, target_pos_ratio=0.5, force_aug_method=None):
    target_data, _ = arff.loadarff(target_file)
    df_target = pd.DataFrame(target_data)
    for col in df_target.columns:
        if df_target[col].dtype == object:
            df_target[col] = df_target[col].apply(lambda x: x.decode('utf-8') if isinstance(x, bytes) else x)
    Xt_full = df_target.iloc[:, :-1].values.astype(np.float32)
    yt_full = df_target.iloc[:, -1].apply(clean_and_binarize_label).values.astype(np.int64)
    Xt_full = StandardScaler().fit_transform(Xt_full)
    source_data, source_labels, selected_methods = [], [], []
    for folder in source_folders:
        for filename in os.listdir(folder):
            if filename.endswith('.arff'):
                file_path = os.path.join(folder, filename)
                if os.path.abspath(file_path) == os.path.abspath(target_file):
                    continue
                try:
                    data, _ = arff.loadarff(file_path)
                    df = pd.DataFrame(data)
                    for col in df.columns:
                        if df[col].dtype == object:
                            df[col] = df[col].apply(lambda x: x.decode('utf-8') if isinstance(x, bytes) else x)
                    X = df.iloc[:, :-1].values.astype(np.float32)
                    y = df.iloc[:, -1].apply(clean_and_binarize_label).values.astype(np.int64)
                    X = StandardScaler().fit_transform(X)
                    Xt_sample = Xt_full[np.random.choice(len(Xt_full), int(0.1 * len(Xt_full)), replace=False)]
                    if force_aug_method:
                        X_aug, y_aug = AUGMENTATION_METHODS[force_aug_method](X, y)
                        method = force_aug_method
                    else:
                        X_aug, y_aug, method = intelligent_augmentation_ga(X, y, Xt_sample)
                    source_data.append(X_aug)
                    source_labels.append(y_aug)
                    selected_methods.append(method)
                except Exception as e:
                    print(f"⚠️ 跳过文件 {filename}，因为出错：{e}")
    Xt_train, Xt_test, yt_train, yt_test = train_test_split(
        Xt_full, yt_full, test_size=0.3, random_state=42, stratify=yt_full
    )
    return source_data, source_labels, Xt_train, yt_train, Xt_test, yt_test, selected_methods
def generate_augmented_data(X_train, y_train):
    # 使用源域自身采样生成目标增强数据（Xt_sample默认为源域自身子集）
    Xt_sample = X_train[np.random.choice(len(X_train), int(0.1 * len(X_train)), replace=False)]
    X_aug, y_aug, _ = intelligent_augmentation_ga(X_train, y_train, Xt_sample)
    return X_aug, y_aug